-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql108.infinityfree.com
-- Generation Time: Nov 24, 2026 at 11:59 AM
-- Server version: 11.4.14-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43524489_electronic_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warranty` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `brand`, `price`, `quantity`, `warranty`, `description`, `created_at`) VALUES
(1, 'Gaming Laptop', 'Laptop', 'ASUS', '45000.00', 10, '2 Years', 'High performance gaming laptop', '2026-11-24 15:22:50'),
(2, 'iPhone 15', 'Smartphone', 'Apple', '42000.00', 15, '1 Year', 'Apple smartphone', '2026-11-24 15:22:50'),
(3, 'Smart TV 43 inch', 'Television', 'Samsung', '25000.00', 8, '2 Years', '4K Smart Television', '2026-11-24 15:22:50'),
(4, 'Wireless Headphones', 'Audio Devices', 'Sony', '3500.00', 20, '1 Year', 'Bluetooth wireless headphones', '2026-11-24 15:22:50'),
(5, 'Gaming Mouse', 'Computer Accessories', 'Logitech', '1500.00', 30, '1 Year', 'RGB gaming mouse', '2026-11-24 15:22:50'),
(6, 'redmi note 3', 'Smartphone', 'redmi', '7999.00', 5, '1 Year', 'd gedgsdgsdghsd', '2026-11-24 15:35:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
